-- Activity lease intervals are a proxy for execution; timestamp ties finish first.
WITH intervals AS (
 SELECT w.run_id,t.id,t.payload->>'resourceId' AS resource_id,a.claimed_at,a.finished_at
 FROM wfc_scale.hub_task t
 JOIN wfc_scale.hub_workflow w ON w.id=t.workflow_id
 JOIN wfc_scale.hub_task_attempt a ON a.task_id=t.id
 WHERE (w.run_id LIKE 'decomp-%-20261109' OR w.run_id IN ('prometheus-keyed-1-20261109','prometheus-keyed-2-20261109')) AND t.task_type IN ('policy-keyed-step','policy-unordered-step')
   AND a.finished_at IS NOT NULL
), events AS (
 SELECT run_id,claimed_at AS at,1 AS delta FROM intervals
 UNION ALL
 SELECT run_id,finished_at AS at,-1 AS delta FROM intervals
), counts AS (
 SELECT run_id,at,delta,sum(delta) OVER (PARTITION BY run_id ORDER BY at,delta ROWS UNBOUNDED PRECEDING) AS active FROM events
)
SELECT run_id,max(active) AS peak_activity_leases FROM counts GROUP BY run_id ORDER BY run_id;

SELECT w.run_id,count(DISTINCT t.payload->>'resourceId') AS distinct_keys,count(*) AS tasks
FROM wfc_scale.hub_task t JOIN wfc_scale.hub_workflow w ON w.id=t.workflow_id
WHERE (w.run_id LIKE 'decomp-%-20261109' OR w.run_id IN ('prometheus-keyed-1-20261109','prometheus-keyed-2-20261109'))
  AND t.task_type IN ('policy-keyed-step','policy-unordered-step')
GROUP BY w.run_id ORDER BY w.run_id;
