import json
from collections import defaultdict
from pathlib import Path

for p in sorted(Path(__file__).parent.glob('prometheus-keyed-*-decomposition.json')):
    d=json.loads(p.read_text()); start=d['invocation_start_utc']; end=d['invocation_end_utc']; q=d['queries']
    print(p.name)
    for base in ['workflow_hub_claim_admission_wait_seconds','workflow_hub_claim_db_connection_acquire_seconds','workflow_hub_claim_candidate_query_seconds','workflow_hub_claim_permit_check_seconds','workflow_hub_claim_candidates_scanned','workflow_hub_claim_tasks_returned','workflow_hub_worker_body_duration_seconds','workflow_hub_worker_execution_duration_seconds','workflow_hub_worker_completion_http_duration_seconds','workflow_hub_native_commit_duration_seconds','workflow_hub_native_workflow_row_lock_duration_seconds']:
        totals=defaultdict(lambda:[0.0,0.0])
        for idx,suffix in enumerate(('_sum','_count')):
            for s in q[base+suffix]['response']['data']['result']:
                vals=[float(v) for t,v in s['values'] if start-5 <= t <= end+10]
                if len(vals)>=2 and vals[-1]>=vals[0]:
                    group=s['metric'].get('activity_type','all')
                    totals[group][idx]+=vals[-1]-vals[0]
        for group,(summ,count) in totals.items():
            if count: print(base,group,'count',round(count,1),'mean',round(summ/count,6))
