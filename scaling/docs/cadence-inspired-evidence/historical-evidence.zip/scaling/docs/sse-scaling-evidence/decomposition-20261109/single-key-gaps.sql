WITH leases AS (
 SELECT w.run_id,a.claimed_at,a.finished_at,lead(a.claimed_at) OVER (PARTITION BY w.run_id ORDER BY a.claimed_at) AS next_claimed_at
 FROM wfc_scale.hub_task t JOIN wfc_scale.hub_workflow w ON w.id=t.workflow_id
 JOIN wfc_scale.hub_task_attempt a ON a.task_id=t.id
 WHERE w.run_id IN ('decomp-key1-a-20261109','decomp-key1-b-20261109') AND t.task_type='policy-keyed-step'
)
SELECT run_id,count(*) AS leases,
 round(extract(epoch FROM max(finished_at)-min(claimed_at))::numeric,3) AS first_to_last_lease_seconds,
 round(sum(extract(epoch FROM finished_at-claimed_at))::numeric,3) AS sum_lease_seconds,
 round(percentile_cont(0.5) WITHIN GROUP (ORDER BY extract(epoch FROM next_claimed_at-finished_at)*1000)::numeric,2) AS gap_p50_ms,
 round(percentile_cont(0.95) WITHIN GROUP (ORDER BY extract(epoch FROM next_claimed_at-finished_at)*1000)::numeric,2) AS gap_p95_ms
FROM leases GROUP BY run_id ORDER BY run_id;

WITH leases AS (
 SELECT w.run_id,t.created_at,a.claimed_at,a.finished_at,
 lead(a.claimed_at) OVER (PARTITION BY w.run_id ORDER BY a.claimed_at) AS next_claimed_at
 FROM wfc_scale.hub_task t JOIN wfc_scale.hub_workflow w ON w.id=t.workflow_id
 JOIN wfc_scale.hub_task_attempt a ON a.task_id=t.id
 WHERE w.run_id IN ('decomp-key1-a-20261109','decomp-key1-b-20261109') AND t.task_type='policy-keyed-step'
)
SELECT l.run_id,count(*) AS gaps,
 count(*) FILTER (WHERE EXISTS (SELECT 1 FROM leases n WHERE n.run_id=l.run_id AND n.created_at<=l.finished_at AND n.claimed_at>=l.next_claimed_at)) AS gaps_with_already_created_future_task
FROM leases l WHERE l.next_claimed_at IS NOT NULL GROUP BY l.run_id ORDER BY l.run_id;
