-- First lease only, elapsed from durable task creation (not proven eligible time).
WITH first_attempt AS (
 SELECT DISTINCT ON (task_id) task_id,claimed_at,finished_at
 FROM wfc_scale.hub_task_attempt ORDER BY task_id,claimed_at
), samples AS (
 SELECT w.run_id,t.task_type,extract(epoch from (a.claimed_at-t.created_at))*1000 AS created_to_claim_ms,
 extract(epoch from (a.finished_at-a.claimed_at))*1000 AS lease_ms
 FROM wfc_scale.hub_task t JOIN wfc_scale.hub_workflow w ON w.id=t.workflow_id
 JOIN first_attempt a ON a.task_id=t.id
 WHERE (w.run_id LIKE 'decomp-%-20261109' OR w.run_id IN ('prometheus-keyed-1-20261109','prometheus-keyed-2-20261109'))
)
SELECT run_id,task_type,count(*) AS tasks,
 round(percentile_cont(0.5) WITHIN GROUP (ORDER BY created_to_claim_ms)::numeric,2) AS created_to_claim_p50_ms,
 round(percentile_cont(0.95) WITHIN GROUP (ORDER BY created_to_claim_ms)::numeric,2) AS created_to_claim_p95_ms,
 round(percentile_cont(0.99) WITHIN GROUP (ORDER BY created_to_claim_ms)::numeric,2) AS created_to_claim_p99_ms,
 round(percentile_cont(0.5) WITHIN GROUP (ORDER BY lease_ms)::numeric,2) AS lease_p50_ms,
 round(percentile_cont(0.95) WITHIN GROUP (ORDER BY lease_ms)::numeric,2) AS lease_p95_ms
FROM samples GROUP BY run_id,task_type ORDER BY run_id,task_type;
