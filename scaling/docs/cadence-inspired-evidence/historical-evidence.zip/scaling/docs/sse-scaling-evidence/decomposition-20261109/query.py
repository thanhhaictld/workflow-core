import datetime as dt
import json
import sys
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import urlopen

here = Path(__file__).parent
parent = here.parent
names = '''workflow_hub_claim_admission_wait_seconds workflow_hub_claim_db_connection_acquire_seconds workflow_hub_claim_candidate_query_seconds workflow_hub_claim_permit_check_seconds workflow_hub_claim_candidates_scanned workflow_hub_claim_tasks_returned workflow_hub_worker_body_duration_seconds workflow_hub_worker_execution_duration_seconds workflow_hub_worker_completion_http_duration_seconds workflow_hub_native_commit_duration_seconds workflow_hub_native_workflow_row_lock_duration_seconds'''.split()
gauges = '''workflow_hub_queue_ready workflow_hub_queue_leased workflow_hub_worker_inflight workflow_hub_threadpool_pending workflow_hub_claim_admission_active workflow_hub_sse_task_sessions dotnet_process_cpu_time_seconds_total'''.split()
queries = {n + suffix: n + suffix for n in names for suffix in ('_bucket', '_count', '_sum')}
queries.update({n: n for n in gauges})

def epoch(p):
    return dt.datetime.fromisoformat(p.read_text().strip().replace('Z', '+00:00')).timestamp()

runs = ('prometheus-keyed-1-20261109', 'prometheus-keyed-2-20261109') if len(sys.argv) == 1 else sys.argv[1:]
for run in runs:
    source = parent if run.startswith('prometheus-') else here
    start = epoch(source / (run + '-start.txt'))
    end = epoch(source / (run + '-end.txt'))
    result = {'run': run, 'invocation_start_utc': start, 'invocation_end_utc': end,
              'query_start_utc': start - 35, 'query_end_utc': end + 15, 'step_seconds': 5, 'queries': {}}
    for name, query in queries.items():
        params = urlencode({'query': query, 'start': start - 35, 'end': end + 15, 'step': 5})
        with urlopen('http://127.0.0.1:19090/api/v1/query_range?' + params) as response:
            result['queries'][name] = {'query': query, 'response': json.load(response)}
    (here / (run + '-decomposition.json')).write_text(json.dumps(result, indent=2))
