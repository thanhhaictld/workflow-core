$ErrorActionPreference='Stop'
$env:WFC_OBSERVABILITY_PROJECT='wfc-sse-measurement-20261109'
$env:HUB_PORT='15100'; $env:HUB_LB_PORT='15110'; $env:OTLP_HTTP_PORT='14318'; $env:PROMETHEUS_PORT='19090'
$env:WFC_HUB_TASK_SSE_PUSH='true'; $env:WFC_HUB_MATCHING_EVENT_GATED='true'; $env:WFC_HUB_CLAIM_ADMISSION_ENABLED='true'; $env:WFC_HUB_CLAIM_ADMISSION_MODE='demand'; $env:WFC_HUB_BATCH_UNCONSTRAINED_CLAIMS='true'
$env:POLICY_BENCHMARK_ENABLED='true'; $env:POLICY_BENCHMARK_ONLY='true'; $env:POLICY_BENCH_ACTIVITY_WORKERS='8'; $env:OFFBOARD_PROCESSOR_WORKERS='8'
$env:WFC_HUB_VERIFY_URL='http://127.0.0.1:15110'
$dir='scaling/docs/sse-scaling-evidence/decomposition-20261109'
$files=@('-f','scaling/observability/compose.yaml','-f','scaling/observability/compose.matching-ha.yaml','-f','scaling/observability/compose.matching-shards.yaml','-f',"$dir/compose.keys.yaml",'--env-file','scaling/observability/.env.example')
git rev-parse HEAD | Set-Content "$dir/build-identity.txt"
git status --short | Add-Content "$dir/build-identity.txt"
Get-FileHash scaling/observability/compose.yaml,scaling/observability/compose.matching-ha.yaml,scaling/observability/compose.matching-shards.yaml,scaling/observability/k6/partition-ordering.js,"$dir/partition-ordering-keys.js" -Algorithm SHA256 | Format-List | Out-String | Add-Content "$dir/build-identity.txt"
docker compose @files --profile offboarding-load up -d --no-build prometheus postgres-process-exporter hub hub-2 hub-lb --scale processor=4 processor
if ($LASTEXITCODE -ne 0) { throw 'Isolated stack start failed' }
docker inspect --format '{{.Name}} {{.Image}}' wfc-sse-measurement-20261109-hub-1 wfc-sse-measurement-20261109-hub-2-1 wfc-sse-measurement-20261109-processor-1 wfc-sse-measurement-20261109-processor-2 wfc-sse-measurement-20261109-processor-3 wfc-sse-measurement-20261109-processor-4 | Add-Content "$dir/build-identity.txt"
Start-Sleep -Seconds 30
$runs=@(@('warm','keyed',8,100),@('unordered-a','unordered',8,200),@('key1-a','keyed',1,200),@('key8-a','keyed',8,200),@('key32-a','keyed',32,200),@('key64-a','keyed',64,200),@('key64-b','keyed',64,200),@('key32-b','keyed',32,200),@('key8-b','keyed',8,200),@('key1-b','keyed',1,200),@('unordered-b','unordered',8,200))
foreach ($run in $runs) {
  $id="decomp-$($run[0])-20261109"; $mode=$run[1]; $keys=$run[2]; $count=$run[3]
  (Get-Date).ToUniversalTime().ToString('o') | Set-Content "$dir/$id-start.txt"
  docker compose @files --profile policy-k6 run --rm --no-deps -e "K6_POLICY_MODE=$mode" -e "K6_POLICY_KEYS=$keys" -e "K6_POLICY_COUNT=$count" -e K6_POLICY_VUS=40 -e K6_POLICY_TIMEOUT_SECONDS=300 -e "K6_POLICY_RUN_ID=$id" k6-policy 2>&1 | Tee-Object "$dir/$id.log"
  $status=$LASTEXITCODE
  (Get-Date).ToUniversalTime().ToString('o') | Set-Content "$dir/$id-end.txt"
  if (Test-Path "$dir/k6-policy-summary.json") { Move-Item "$dir/k6-policy-summary.json" "$dir/$id-summary.json" }
  if ($status -ne 0) { throw "Failed $id ($status)" }
  python scaling/docs/sse-scaling-evidence/verify-isolated.py --mode $mode --run-id $id --count $count --output "$dir/$id-verification.json" *> "$dir/$id-verifier.log"
  if ($LASTEXITCODE -ne 0) { throw "Verifier failed for $id" }
  Start-Sleep -Seconds 10
}
