import datetime as dt
import json
import math
from pathlib import Path

root = Path(__file__).parent
metrics = '''workflow_hub_claim_admission_wait_seconds workflow_hub_claim_db_connection_acquire_seconds workflow_hub_claim_candidate_query_seconds workflow_hub_claim_permit_check_seconds workflow_hub_claim_candidates_scanned workflow_hub_claim_tasks_returned workflow_hub_worker_body_duration_seconds workflow_hub_worker_execution_duration_seconds workflow_hub_worker_completion_http_duration_seconds workflow_hub_native_commit_duration_seconds workflow_hub_native_workflow_row_lock_duration_seconds'''.split()

def values(series, start, end):
    return [(t, float(v)) for t, v in series['values'] if start - 5 <= t <= end + 10 and math.isfinite(float(v))]

for path in sorted(root.glob('prometheus-keyed-*-decomposition.json')):
    data = json.loads(path.read_text())
    q, start, end = data['queries'], data['invocation_start_utc'], data['invocation_end_utc']
    lines = [path.name, 'Counter deltas use samples from up to 5 s before invocation until 10 s after; shared background included.']
    for metric in metrics:
        bucket = {}
        for s in q[metric + '_bucket']['response']['data']['result']:
            a = values(s, start, end)
            if len(a) >= 2 and a[-1][1] >= a[0][1]:
                bound = float(s['metric']['le'])
                bucket[bound] = bucket.get(bound, 0) + a[-1][1] - a[0][1]
        if not bucket or bucket.get(float('inf'), 0) <= 0:
            lines.append(f'{metric}: no measurable delta')
            continue
        total = bucket[float('inf')]
        # Conservative histogram bucket ceilings, avoiding invented interpolation.
        limits = [next((k for k in sorted(bucket) if bucket[k] >= total*p), float('nan')) for p in (.5,.95,.99)]
        lines.append(f'{metric}: count={total:g}, bucket_upper_p50/p95/p99={limits}')
    lines.append('Aligned snapshots: time UTC, max reported ready/leased, sum activity inflight, activity instances observed, per-instance threadpool pending')
    results = {k: v['response']['data']['result'] for k, v in q.items()}
    def at(metric, ts):
        return [(s['metric'], float(v)) for s in results[metric] for t,v in s['values'] if t == ts and math.isfinite(float(v))]
    tslist = sorted({t for s in results['workflow_hub_queue_ready'] for t,v in s['values'] if start <= t <= end})
    for ts in tslist:
        ready = at('workflow_hub_queue_ready', ts); leased = at('workflow_hub_queue_leased', ts)
        inflight = at('workflow_hub_worker_inflight', ts); pending = at('workflow_hub_threadpool_pending', ts)
        lines.append(f'{dt.datetime.fromtimestamp(ts,dt.timezone.utc).isoformat()} ready={max((v for _,v in ready), default=-1):g} leased={max((v for _,v in leased), default=-1):g} inflight={sum(v for _,v in inflight):g} activity_series={len(inflight)} pending={[(m.get("service_instance_id"),v) for m,v in pending]}')
    (root / (path.stem + '-analysis.txt')).write_text('\n'.join(lines)+'\n')
