$ErrorActionPreference = 'Stop'
$env:WFC_OBSERVABILITY_PROJECT='wfc-sse-measurement-20261109'
$env:HUB_PORT='15100'; $env:HUB_LB_PORT='15110'; $env:OTLP_HTTP_PORT='14318'
$env:WFC_HUB_TASK_SSE_PUSH='true'; $env:WFC_HUB_MATCHING_EVENT_GATED='true'
$env:WFC_HUB_CLAIM_ADMISSION_ENABLED='true'; $env:WFC_HUB_CLAIM_ADMISSION_MODE='demand'; $env:WFC_HUB_BATCH_UNCONSTRAINED_CLAIMS='true'
$env:POLICY_BENCHMARK_ENABLED='true'; $env:POLICY_BENCHMARK_ONLY='true'; $env:POLICY_BENCH_ACTIVITY_WORKERS='8'; $env:OFFBOARD_PROCESSOR_WORKERS='8'
$files=@('-f','scaling/observability/compose.yaml','-f','scaling/observability/compose.matching-ha.yaml','-f','scaling/observability/compose.matching-shards.yaml','-f','scaling/docs/sse-scaling-evidence/compose.measurement.yaml','--env-file','scaling/observability/.env.example')
docker compose @files --profile offboarding-load up -d --build --no-deps --scale processor=4 processor
if ($LASTEXITCODE -ne 0) { throw 'Processor start failed' }
Start-Sleep -Seconds 15
foreach ($mode in @('unordered','partition','keyed')) {
  foreach ($n in 1..2) {
    $id="measure-$mode-$n-20261109"
    docker compose @files --profile policy-k6 run --rm --no-deps -e "K6_POLICY_MODE=$mode" -e K6_POLICY_COUNT=100 -e K6_POLICY_VUS=40 -e K6_POLICY_TIMEOUT_SECONDS=180 -e "K6_POLICY_RUN_ID=$id" k6-policy 2>&1 | Tee-Object "scaling/docs/sse-scaling-evidence/$id.log"
    $status=$LASTEXITCODE
    if (Test-Path scaling/docs/sse-scaling-evidence/k6-policy-summary.json) { Move-Item -Force scaling/docs/sse-scaling-evidence/k6-policy-summary.json "scaling/docs/sse-scaling-evidence/$id-summary.json" }
    "exit=$status" | Add-Content "scaling/docs/sse-scaling-evidence/$id.log"
    if ($status -ne 0) { throw "Failed: $id" }
  }
}
