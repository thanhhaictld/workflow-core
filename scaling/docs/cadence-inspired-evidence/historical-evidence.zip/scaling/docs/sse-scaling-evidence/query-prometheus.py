import datetime as dt
import json
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import urlopen

root = Path(__file__).parent
queries = {
    'up': 'up',
    'db_connections': 'max(workflow_hub_database_connections)',
    'db_active_connections': 'max(workflow_hub_database_active_connections)',
    'ready_tasks': 'max(workflow_hub_queue_ready)',
    'leased_tasks': 'max(workflow_hub_queue_leased)',
    'sse_sessions': 'sum(workflow_hub_sse_task_sessions)',
    'rss_by_instance': 'workflow_hub_process_working_set_bytes',
    'postgres_cpu_cores': 'sum(rate(namedprocess_namegroup_cpu_seconds_total[30s]))',
    'postgres_rss': 'sum(namedprocess_namegroup_memory_bytes{memtype="resident"})',
    'claim_p95_seconds': 'histogram_quantile(0.95, sum by (le) (rate(workflow_hub_claim_duration_seconds_bucket[30s])))',
    'claim_p99_seconds': 'histogram_quantile(0.99, sum by (le) (rate(workflow_hub_claim_duration_seconds_bucket[30s])))',
    'dispatch_p95_seconds': 'histogram_quantile(0.95, sum by (le) (rate(workflow_hub_matching_dispatch_duration_seconds_bucket[30s])))',
    'dispatch_p99_seconds': 'histogram_quantile(0.99, sum by (le) (rate(workflow_hub_matching_dispatch_duration_seconds_bucket[30s])))',
    'sse_dispatch_rate': 'sum(rate(workflow_hub_sse_tasks_dispatched_total[30s]))',
    'notify_received_rate': 'sum(rate(workflow_hub_pg_notify_received_total[30s]))',
    'notify_forwarded_rate': 'sum(rate(workflow_hub_pg_notify_forwarded_total[30s]))',
    'process_cpu_by_instance': 'rate(dotnet_process_cpu_time_seconds_total[30s])',
    'k6_failed': 'k6_http_req_failed_rate',
}

def epoch(path):
    return dt.datetime.fromisoformat(path.read_text().strip().replace('Z', '+00:00')).timestamp()

for n in (1, 2):
    prefix = f'prometheus-keyed-{n}-20261109'
    start = epoch(root / f'{prefix}-start.txt')
    end = epoch(root / f'{prefix}-end.txt')
    results = {'start': start, 'end': end, 'step_seconds': 5, 'queries': {}}
    for name, query in queries.items():
        params = urlencode({'query': query, 'start': start, 'end': end + 15, 'step': 5})
        with urlopen('http://127.0.0.1:19090/api/v1/query_range?' + params) as response:
            results['queries'][name] = {'query': query, 'response': json.load(response)}
    (root / f'{prefix}-prometheus.json').write_text(json.dumps(results, indent=2))
