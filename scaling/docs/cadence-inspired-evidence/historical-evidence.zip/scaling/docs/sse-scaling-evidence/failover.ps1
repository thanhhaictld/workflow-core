$ErrorActionPreference='Stop'
$env:WFC_OBSERVABILITY_PROJECT='wfc-sse-measurement-20261109'; $env:HUB_PORT='15100'; $env:HUB_LB_PORT='15110'; $env:OTLP_HTTP_PORT='14318'
$env:WFC_HUB_TASK_SSE_PUSH='true'; $env:WFC_HUB_MATCHING_EVENT_GATED='true'; $env:WFC_HUB_CLAIM_ADMISSION_ENABLED='true'; $env:WFC_HUB_CLAIM_ADMISSION_MODE='demand'; $env:WFC_HUB_BATCH_UNCONSTRAINED_CLAIMS='true'
$env:POLICY_BENCHMARK_ENABLED='true'; $env:POLICY_BENCHMARK_ONLY='true'; $env:POLICY_BENCH_ACTIVITY_WORKERS='8'; $env:OFFBOARD_PROCESSOR_WORKERS='8'; $env:WFC_HUB_VERIFY_URL='http://127.0.0.1:15110'
$files=@('-f','scaling/observability/compose.yaml','-f','scaling/observability/compose.matching-ha.yaml','-f','scaling/observability/compose.matching-shards.yaml','-f','scaling/docs/sse-scaling-evidence/compose.measurement.yaml','--env-file','scaling/observability/.env.example')
Get-Date -Format o | Out-File scaling/docs/sse-scaling-evidence/failover-times.txt
docker stop -t 0 wfc-sse-measurement-20261109-hub-1
Start-Sleep -Seconds 12
Get-Date -Format o | Add-Content scaling/docs/sse-scaling-evidence/failover-times.txt
foreach ($n in 1..2) {
 $id="measure-failover-$n-20261109"
 docker compose @files --profile policy-k6 run --rm --no-deps -e K6_POLICY_MODE=keyed -e K6_POLICY_COUNT=100 -e K6_POLICY_VUS=40 -e K6_POLICY_TIMEOUT_SECONDS=180 -e "K6_POLICY_RUN_ID=$id" k6-policy 2>&1 | Tee-Object "scaling/docs/sse-scaling-evidence/$id.log"
 $status=$LASTEXITCODE
 if (Test-Path scaling/docs/sse-scaling-evidence/k6-policy-summary.json) { Move-Item -Force scaling/docs/sse-scaling-evidence/k6-policy-summary.json "scaling/docs/sse-scaling-evidence/$id-summary.json" }
 if ($status -ne 0) { throw "Failed $id" }
 python scaling/docs/sse-scaling-evidence/verify-isolated.py --mode keyed --run-id $id --count 100 --output "scaling/docs/sse-scaling-evidence/$id-verification.json"
 if ($LASTEXITCODE -ne 0) { throw "Verification failed $id" }
}
docker exec wfc-sse-measurement-20261109-postgres-1 psql -U workflow -d workflow -c 'TABLE wfc_scale.hub_matching_partition_owner' | Out-File scaling/docs/sse-scaling-evidence/owners-after.txt
