# SSE task distribution: from workflow start to worker execution

**Scope:** a detailed companion to [SSE task distributor](sse-task-distributor.md),
checked against this branch's source on 9 November 2026. Task push is experimental
and **off by default**. The diagrams describe the native remote workflow path
with sharded matching and SSE task push enabled. They do not establish that a
particular deployment has enabled it.

The main flow is:

> An application starts a workflow over REST. The Hub transactionally stores the
> workflow and a workflow task in PostgreSQL. A remote workflow worker decides
> what to run and commits activity tasks back to the Hub. The matching owner
> leases an eligible task for a compatible worker that has offered a free slot,
> then sends that lease over the worker's existing SSE connection. Activity
> completion durably wakes the workflow again.

Read sections 1–3 for the overall model, then phases 0–9 for the detailed path.
Section 14 provides a worked trace; section 16 links to the implementation.

## 1. High-level architecture

```mermaid
flowchart TB
    App["Application"]
    GW["Hub Gateway through public load balancer"]
    PG[("PostgreSQL durable workflow state and tasks")]
    Match["Hub matching owner and SSE distributor"]
    Scheduler["Hub timer scheduler"]
    subgraph Remote["Remote application host; no PostgreSQL access"]
        WF["Workflow lane"]
        ACT["Activity lane"]
    end
    App -->|"REST start"| GW
    GW -->|"transactional writes"| PG
    PG <-->|"readiness and durable claims"| Match
    Scheduler -->|"durable wakeups"| PG
    Match -->|"SSE workflow task"| WF
    Match -->|"SSE activity task"| ACT
    WF -->|"REST decisions and effects"| GW
    ACT -->|"REST heartbeat and result"| GW
```

The arrows from the distributor to remote lanes are responses on connections
the workers opened. The Hub does not initiate an inbound connection to a worker
address. A non-owner Gateway can relay these responses through the load balancer.

The Hub stores and validates declarative registrations and execution effects.
Business workflow C# and activity handlers execute in the remote host. A combined
host can run both lanes, but their concurrency limits and worker identities are
separate.

## 2. Names that must stay distinct

| Term | Meaning | Example used in this guide |
| --- | --- | --- |
| Business Hub / namespace | Logical grouping of registrations and tasks; `hubId` | `example` |
| Hub replica | An infrastructure process serving REST/SSE | Hub A, Hub B |
| Workflow definition version | Version of registered workflow code | `example-onboarding`, version `3` |
| Workflow instance | One durable execution of that definition | Workflow W |
| Workflow task | A short execution turn that advances workflow state | `__native_workflow__`, task version `1` |
| Activity task | A durable request to execute a business handler | `provision-tenant`, activity version `3` |
| Persisted partition | `partition_id` stored on the workflow and its tasks | Partition `13` out of `32` |
| Matching shard | Ownership/routing slice calculated from persisted partition | `13 % 4 = 1` |
| Matching owner epoch | Generation of the Hub owning a namespace/shard | Epoch `12` |
| Task lease epoch | Generation of one task's execution ownership | Epoch `7` |
| Worker lane | Independently bounded workflow or activity consumer | Activity lane capacity `2` |
| SSE session | Ephemeral subscription for one worker, namespace and shard | Session S |
| Credit | A one-shot reservation of one free execution slot | Credit C |

A definition's version `3`, the native workflow task protocol version `1`, and
an activity's version `3` are different fields. Matching a workflow worker also
checks its advertised definition ID/version, when supplied by the worker.

## 3. Lifecycle and transaction boundaries

| Phase | Trigger / input | Responsible component | Durable result or transport outcome |
| --- | --- | --- | --- |
| 0. Register | Application host starts | Runtime publisher → Hub | Definition metadata and activity policies |
| 1. Start | Application sends workflow start | Gateway → remote workflow store | Workflow, first workflow task and start history in one transaction |
| 2. Place | Hub creates workflow/tasks | Partition router and stores | Immutable workflow partition; matching shard derived from it |
| 3. Connect | Worker lane starts/reconnects | Gateway → matching owner → distributor | Ephemeral SSE session with owner epoch |
| 4. Offer capacity | Lane has a free execution slot | Worker credit coordinator | REST credit accepted into owner's session queue |
| 5. Discover ready work | Task commit, permit release or recovery scan | PostgreSQL listener → readiness → matcher | Compatible waiting claim is signalled; no task ownership yet |
| 6. Admit and lease | Credited session invokes matcher | Matcher → PostgreSQL task store | Eligible task leased, task epoch incremented, applicable attempt/history recorded |
| 7. Deliver and execute | Claim returns one task | Distributor → SSE → remote lane | Worker validates reservation and starts the task |
| 8. Complete and advance | Workflow decision or activity result | Remote lane → transactional Hub store | Snapshot/effects or result/inbox/wakeup committed |
| 9. Recover | Disconnect, owner loss or execution failure | Worker, ownership loop and durable recovery | New session or lease retry; committed state retained |

Phases 3–4 can occur before any workflows exist. A subscription does not need a
backlog, and submitting a workflow does not require connected workers. If no
worker can claim a task, it remains durable in PostgreSQL.

## 4. Phase 0 — register executable capabilities and policies

Before claiming work, `HubRuntimePublisher` publishes activity registrations and
workflow definitions over REST. The worker lanes wait for publication to finish.

```mermaid
sequenceDiagram
    autonumber
    participant Host as Remote application host
    participant Hub as Hub registration endpoints
    participant PG as PostgreSQL
    Host->>Hub: POST activity-registrations (type, version, policies)
    Hub->>PG: Persist declarative activity registration
    Host->>Hub: POST definitions (ID, version, partitions, native metadata)
    Hub->>PG: Persist definition metadata
    Host->>Host: Mark publication complete and start worker lanes
```

The remote host retains the executable C# definitions and handlers. The Hub
receives metadata, input contracts and declarative resource rules, not arbitrary
code to execute. Resource keys are derived by the Hub from validated activity
input. A worker cannot grant itself additional resource permits.

The workflow lane advertises `__native_workflow__` version `1`, plus definition
capabilities such as `(example, example-onboarding, 3)`. The activity lane
advertises triples such as `(example, provision-tenant, 3)`. These capabilities
later filter both waiting requests and SQL candidates.

Source: [runtime publisher and lane definitions](../src/WorkflowCore.RemoteExecution/HubRuntimeWorkers.cs),
[registration store](../src/WorkflowCore.Hub/HubDefinitionStore.cs).

## 5. Phase 1 — trigger a workflow and send it to the server

The trigger is an application call. This might be an HTTP handler in your own
API, a scheduled application job, or a load generator. It calls the Hub's start
API; merely registering a definition does not start an execution.

An illustrative native SDK call, assuming this definition and data contract
have already been registered:

```csharp
Guid workflowId = await hubWorkflowClient.StartAsync(
    hub: "example",
    definition: "example-onboarding",
    version: 3,
    data: new OnboardingData { TenantId = "tenant-42" },
    idempotencyKey: "onboarding-request-42",
    ct: cancellationToken);
```

`HubWorkflowClient` serializes the native CLR data with `HubSnapshotCodec` and
uses `HubRestClient` to send `POST /api/hub/workflows`. The wire envelope has
`hubId`, `definitionId`, `version`, `input`, and optional `idempotencyKey`/`runId`.
Use the SDK codec for typed native inputs; a hand-written JSON object is not
necessarily equivalent to its native serialization.

```mermaid
sequenceDiagram
    autonumber
    participant App as Application
    participant Client as HubWorkflowClient / HubRestClient
    participant GW as Any Hub Gateway via LB
    participant Store as HubRemoteWorkflowStore
    participant PG as PostgreSQL
    App->>Client: StartAsync(namespace, definition, version, data, key)
    Client->>GW: POST /api/hub/workflows
    GW->>Store: StartAsync for published remote/native definition
    Store->>PG: Read definition and BEGIN transaction
    Store->>PG: INSERT hub_workflow with partition and execution mode
    Store->>PG: INSERT first __native_workflow__ task
    Store->>PG: INSERT WorkflowStarted history
    Store->>PG: COMMIT
    PG-->>GW: Committed readiness notification via listener
    GW-->>Client: 202 Accepted with workflowId
    Client-->>App: workflowId
    Note over App,PG: Accepted means durably started, not already completed
```

The sequence shows logical dependencies; delivery of the committed notification
and the HTTP acknowledgement can race. The database transaction precedes both.

For an already accepted identical idempotency key, the store returns the
existing workflow ID without creating another first task. Reusing the key with
different start parameters is rejected. If a published definition is native,
the store calls `HubNativeWorkflowStore.WakeAsync`; sequential remote definitions
instead receive `__workflow__` tasks. The Gateway also retains an inline path
for in-process registrations, outside this guide's remote native flow.

Source: [typed client](../src/WorkflowCore.RemoteExecution/HubWorkflowClient.cs),
[REST client](../src/WorkflowCore.Hub.Client/HubRestClient.cs),
[start endpoint](../src/WorkflowCore.Hub.Gateway/HubGatewayEndpoints.cs),
[start transaction](../src/WorkflowCore.Hub/HubRemoteWorkflowStore.cs).

## 6. Phase 2 — keep the workflow in a partition and route its tasks to a shard

The Hub chooses the persisted workflow partition when it creates the workflow:

```text
digest = SHA256(workflowId.ToByteArray())
partition_id = BitConverter.ToUInt32(digest, 0) % definition.Partitions
matching_shard = partition_id % WFC_HUB_MATCHING_PARTITIONS
```

The first formula comes from `HubPartitionRouter.ForWorkflow`. It hashes the
workflow ID, not the tenant ID. The second formula groups persisted partitions
into matching shards. The workflow task and managed activity tasks inherit the
workflow's stored partition. Activity registrations must support that partition;
the Hub rejects a partition-count mismatch when scheduling activities.

For a hypothetical workflow assigned partition `13`, with `32` persisted
partitions and `4` matching shards:

```mermaid
flowchart LR
    W["Workflow W created with partition_id = 13"]
    PG[("PostgreSQL shared tables")]
    W --> PG
    PG --> S0["Matching shard 0: partitions 0,4,8,12,..."]
    PG --> S1["Matching shard 1: partitions 1,5,9,13,..."]
    PG --> S2["Matching shard 2: partitions 2,6,10,14,..."]
    PG --> S3["Matching shard 3: partitions 3,7,11,15,..."]
    S1 --> A["Current owner: Hub A, epoch 12"]
    A --> WT["Workflow and activity task claims for shard 1"]
```

These are logical queue slices over the shared database tables. The Hub does
not copy a workflow into a durable in-memory shard queue or transfer workflow
rows between Hub replicas when ownership changes.

| Stored data | Purpose |
| --- | --- |
| `hub_workflow` | Workflow identity/version, partition, revision, native snapshot/status |
| `hub_task` | Durable runnable work, payload, type/version, sequence, due time, owner/epoch/lease |
| `hub_task_constraint` + `hub_resource` | Activity resource requirements, capacities and FIFO policy |
| `hub_matching_partition_config` | Agreed matching-shard count for the namespace |
| `hub_matching_partition_owner` | Current shard owner, URL, epoch and expiry |
| `hub_native_inbox` | Activity/event/timer outcomes waiting for workflow processing |
| `hub_task_attempt` + `hub_workflow_event` | Applicable execution attempts and durable workflow history |

Partition placement does not imply serial execution. `PartitionSerial` adds an
explicit capacity-one FIFO permit; unordered tasks in the same partition can
run concurrently. A keyed resource can constrain tasks across multiple
partitions and matching shards.

The workflow partition is persisted and is not recalculated on reconnect.
Changing either partition topology requires a coordinated migration. In
particular, the matching configuration store fails closed if a replica proposes
a different shard count for a namespace already configured in PostgreSQL.

Source: [partition router and ordering rules](../src/WorkflowCore.Hub/HubPolicies.cs),
[task store](../src/WorkflowCore.Hub/HubTaskStore.cs),
[matching configuration/ownership](../src/WorkflowCore.Hub/HubMatchingPartitionLeaseStore.cs).

## 7. Phase 3 — connect each worker lane to the correct matching owners

Each SSE-enabled lane opens **one outbound stream per matching shard** to the
same public Hub URL. With four shards, a host running both eligible lanes opens
four workflow streams and four activity streams. They have different lane
identities and credit coordinators.

```mermaid
sequenceDiagram
    autonumber
    participant W as Worker lane
    participant LB as Public LB
    participant B as Gateway Hub B
    participant PG as PostgreSQL owner store
    participant A as Matching owner Hub A
    participant D as Distributor on A
    W->>LB: POST tasks:stream for namespace example / shard 1
    LB->>B: Subscription lands on B
    B->>PG: Resolve live owner of (example, 1)
    PG-->>B: Hub A URL, owner epoch 12
    B->>A: Forward subscription with bearer authorization
    A->>PG: Validate local matching ownership
    A->>D: Register session bound to epoch 12
    D-->>A: SSE session frame
    A-->>B: Flush SSE frame
    B-->>LB: Relay and flush received chunk
    LB-->>W: session with sessionId and ownerEpoch
```

If there is no live owner, a deterministic preferred peer is tried first; a
reachable Hub can acquire ownership if that preferred peer fails. PostgreSQL's
lease row decides who won, regardless of preference or LB routing. The current
ownership duration is eight seconds, renewed approximately every two seconds.

The subscription includes the worker's capabilities, optional definition pins,
`maxTasks: 1`, shard index/count, lane capacity, and `initialCredits: 0`.
Connecting alone cannot lease tasks. The first `session` frame gives the worker
the identity and epoch needed for subsequent credit offers.

The owner holds an ephemeral session keyed by `(workerId, hubId, shard)` and
assigns it a generated session ID. A replacement session for that key cancels
the preceding local session. A worker does not register on every Hub replica.
Routing moves requests to the owner that holds its current session.

Source: [SSE endpoints](../src/WorkflowCore.Hub.Gateway/HubSseTaskStreamingEndpoints.cs),
[owner resolution and forwarding](../src/WorkflowCore.Hub.Gateway/HubMatchingOwnership.cs),
[session registry](../src/WorkflowCore.Hub.Gateway/HubSseTaskDistributor.cs).

## 8. Phase 4 — reserve a real slot and offer one-shot credit

For **each lane**, one `HubSseWorkerCreditCoordinator` tracks all streams:

```text
running tasks + outstanding undelivered offers <= lane capacity
free slots = lane capacity - running tasks - outstanding offers
```

This budget spans matching shards within that lane. Workflow capacity and
activity capacity remain separate. It is local execution accounting, distinct
from Hub-enforced activity resource capacities in PostgreSQL.

```mermaid
stateDiagram-v2
    [*] --> Free
    Free --> Offered: Reserve slot and send credit to one shard
    Offered --> Running: Valid task.leased for this credit/session
    Offered --> Free: credit.unused
    Offered --> Free: Offer fails or session disconnects
    Running --> Free: Execution/completion handling finishes
    Running --> Running: SSE reconnect preserves running reservation
```

The coordinator reserves a slot **before** posting
`POST /api/hub/workers/tasks:credit`. The request identifies `sessionId`,
`ownerEpoch`, `workerId`, `hubId`, `matchingPartition`, and `creditId`.

The Gateway resolves the current owner, rejects a different owner epoch and
forwards to the owner if needed. The distributor checks session identity,
worker identity, namespace, shard, credit ID and capacity before queuing it.
A `204` response means the offer was accepted; it contains no leased task.

Each accepted offer can yield at most one `task.leased` or `credit.unused`
response while the session remains live. A disconnect can leave its outcome
unknown. Duplicate credit IDs are idempotent within the session's bounded
deduplication window, currently the latest 512 accepted IDs.

For example, capacity `2` can mean one running task on shard `1` and one offer
waiting on shard `0`. No third offer is allowed. If shard `0` returns unused,
that free slot may be offered to shard `1` instead. Capacity `2` with four
connected streams is supported; there is no mandatory fixed slot per shard.

The allocator prefers a shard that recently delivered work for up to three
consecutive preferred selections, then performs a fair rotation. An unused
offer cools its shard for 250 ms. This is a heuristic, not a global optimal
worker placement algorithm. The distributor processes each session's queued
credits sequentially; each active claim has a two-second budget, so an offer
queued behind earlier credits can wait longer overall.

Source: [credit coordinator](../src/WorkflowCore.RemoteExecution/HubSseWorkerCreditCoordinator.cs),
[grant scheduler](../src/WorkflowCore.RemoteExecution/HubRuntimeWorkers.cs),
[offer validation](../src/WorkflowCore.Hub.Gateway/HubSseTaskDistributor.cs).

## 9. Phase 5 — discover committed ready tasks

Readiness hints improve latency. They do not contain task leases and do not
replace durable queue scans.

```mermaid
flowchart TD
    Commit["Transaction makes a task ready"] --> Trigger["PostgreSQL task trigger"]
    Trigger --> Notify["After commit: wfc_hub_matching_ready"]
    Notify --> Listener["Listener on each connected Hub replica"]
    Listener --> Coalesce["Coalesce duplicate hints over about 25 ms"]
    Coalesce --> Ready["HubReadinessBroadcaster.PublishMatchingHint"]
    Ready --> Target["Target namespace and partition_id modulo shard count"]
    Target --> Waiter["Signal compatible waiting claim"]
    Release["Task leaves leased state / resource may become available"] --> Generic["Namespace-wide matching hint"]
    Generic --> Ready
    Recover["Startup / listener reconnect / periodic recovery scans"] --> Ready
    Waiter --> SQL["Attempt SQL admission; task may still be blocked"]
```

Migration 019's trigger emits a typed hint for a newly ready task:

```json
{"hub":"example","type":"provision-tenant","version":3,"partition":13}
```

The matcher routes it to `(example, 1)` because `13 % 4 = 1`. A workflow task
hint uses `__native_workflow__`, so it wakes workflow demand rather than an
activity-only waiter.

When a leased task leaves the leased state, the trigger can instead emit a
namespace-only hint. Releasing a resource can unblock a task in another shard,
so this hint needs a broader rescan. Hint delivery to multiple Hub replicas
does not authorize them all to distribute the same shard: owner validation
still applies.

Notifications are advisory and can be missed. Recovery includes catch-up probes
and `HubReadinessBroadcaster` sweeps. Its base loop runs every two seconds;
event-gated typed matching recovery is throttled to roughly every ten seconds.
Future-due tasks and expired leases also need such scans because passage of
time alone does not fire a task-row update trigger.

Source: [committed hint trigger](../sql/019_hub_matching_partition_hints.sql),
[notification listener](../src/WorkflowCore.Hub.Gateway/PostgresHubNotificationListener.cs),
[readiness and recovery](../src/WorkflowCore.Hub.Gateway/HubReadinessBroadcaster.cs).

## 10. Phase 6 — match activity demand, enforce policy and create the lease

There are two matching decisions:

1. **Which waiting worker demand should try?** In memory, select a request in
   the correct namespace/shard whose advertised type/version supports the hint.
2. **Which task is actually eligible?** In PostgreSQL, enforce capability,
   workflow status/version pins, due time, attempts, resource capacity and FIFO,
   then atomically lease a task to that request's worker ID.

The distributor invokes `HubTaskMatcher.LongPollAsync` when it consumes a
credit. This is an in-process method call, even though the method is named
`LongPollAsync`; an SSE worker is not calling the HTTP `tasks:poll` endpoint for
each delivered task.

```mermaid
flowchart TD
    Credit["Distributor consumes one session credit"] --> Owner["Validate captured matching owner epoch"]
    Owner --> Wait["Register claim demand: hub, shard, capabilities, worker ID"]
    Wait --> Wake["Readiness hint or bounded catch-up probe"]
    Wake --> Select["Select compatible waiter"]
    Select --> Candidate["SQL candidate scan: namespace/shard, type/version,
    due or expired lease, attempts, workflow status and definition pins"]
    Candidate --> Lock["Lock eligible task: SKIP LOCKED"]
    Lock --> Resources["Lock resource rows in key order"]
    Resources --> Eligible{"Capacity available and FIFO satisfied?"}
    Eligible -->|"no"| Next["Try another candidate or wait for readiness"]
    Next --> Wake
    Eligible -->|"yes"| Lease["Lease to worker, increment execution epoch and attempts"]
    Lease --> Commit["Commit lease and applicable history"]
    Commit --> Check["Validate captured owner epoch again"]
    Check --> Push["One leased task for this credit"]
    Wait -->|"No claim delivered within claim budget"| Unused["credit.unused; return slot to allocator"]
```

With `WFC_HUB_MATCHING_EVENT_GATED=true`, `HubEventGatedClaimDispatcher` coalesces
hints and permits one active claim drain per `(namespace, matching shard)` on
that replica. It rotates compatible waiters, continues draining after a success,
and stops empty drains until another hint/probe. With the flag off, the basic
matcher still uses compatible waiters and SQL admission, without that dispatcher.
`WFC_HUB_MATCHING_SCOPED_CLAIMS` optionally narrows a typed drain to the hinted
capability; SQL filtering applies in either case.

For constrained activities, the task store checks all required resources under
their row locks. If live admitted work already consumes the current capacity,
the task cannot be leased. For a strict FIFO resource, an earlier queued or
leased task referencing that resource prevents a later task overtaking it.
This can block a task even if its prospective worker has a free local slot.
Optional unconstrained batch claiming has a separate SQL fast path; it retains
task eligibility and lease fencing. SSE requests still set `maxTasks: 1`.

For example, workers A and B may both support `provision-tenant:3`, but:

| Worker demand | Outcome for a ready task in shard 1 |
| --- | --- |
| A: compatible, shard 1 stream, live session, outstanding credit | Can attempt a claim |
| B: compatible but no outstanding credit | Cannot receive a new pushed task yet |
| C: only supports activity version 2 | Cannot match version 3 |
| D: workflow-only lane | Cannot execute this activity |
| E: compatible demand on shard 0 | Cannot claim the task assigned to shard 1 |
| A with credit, but task's resource is held | Must wait or receive unused credit; local capacity does not override policy |

There is no durable pre-assignment to a particular remote replica at enqueue.
The successful claim assigns `hub_task.owner` to the selected request's worker
ID. In-memory waiter rotation helps distribute demand but provides no strict
global fairness or tenant scheduling guarantee.

**Fencing boundary:** the distributor validates its captured matching owner
epoch before the matcher and after a successful lease. The matcher also checks
current matching ownership. `HubTaskStore.ClaimAsync` does not take that captured
owner epoch as an argument to the task update; its transaction enforces task
admission and creates the independent execution lease epoch. If the post-claim
owner check fails, the task remains leased until normal recovery and is not
sent through the stale session.

Source: [matcher](../src/WorkflowCore.Hub.Gateway/HubTaskMatcher.cs),
[event-gated dispatcher](../src/WorkflowCore.Hub.Gateway/HubEventGatedClaimDispatcher.cs),
[SQL eligibility, resource locks and lease](../src/WorkflowCore.Hub/HubTaskStore.cs),
[outer owner-epoch checks](../src/WorkflowCore.Hub.Gateway/HubSseTaskDistributor.cs).

## 11. Phase 7 — send SSE to the appropriate worker and begin execution

Once the lease commits, the distributor already knows the destination: the
session whose credit started the claim. It invokes that stream's response
writer with `task.leased`. There is no broadcast of the task to all workers.

```mermaid
sequenceDiagram
    autonumber
    participant C as Worker lane credit coordinator
    participant W as Worker SSE reader
    participant GW as LB / Gateway relay
    participant D as Owner distributor session
    participant M as Matcher / task store
    C->>GW: POST tasks:credit for session S, credit C
    GW->>D: Validate owner epoch and offer credit
    D-->>GW: Accepted
    GW-->>C: 204 (offer accepted only)
    D->>M: Claim with S's worker ID, capabilities and shard
    M-->>D: One committed HubLeasedTask
    D->>D: Validate owner epoch after claim
    D-->>GW: task.leased with credit C and leased task
    GW-->>W: Flush/relay SSE frame
    W->>C: Dispatched(shard, session S, credit C, task ID)
    alt Current session and outstanding credit match
        C-->>W: Offer becomes running reservation
        W->>W: Run task with its execution lease epoch
    else Session or credit was invalidated
        C-->>W: Reject frame
        W->>W: Skip execution and let durable lease recover normally
    end
```

The acceptance response and task frame travel on separate HTTP requests; a fast
task frame can arrive before the credit POST's response. The worker reserves
before posting, so it can validate either arrival order.

The task payload contains `id`, `hubId`, `partitionId`, `taskType`, `version`,
`workflowId`, `payload`, `epoch`, `attempts`, and `leaseUntil`. In this object,
`epoch` is the **task execution lease epoch**, not the session's `ownerEpoch`.

The worker parses the frame and atomically changes the matching outstanding
offer into a running reservation. It rejects a stale session, absent credit or
already-running task ID. Accepted tasks begin through the lane's execution
handler; there is no extra local queue waiting for an execution slot.

Transport details matter: this is HTTP **POST** returning `text/event-stream`,
read by the .NET HTTP client, rather than a browser `EventSource` GET. The
owner flushes each frame; a forwarding Hub flushes each received relay chunk;
the SSE route disables proxy buffering. Credits, heartbeats and results go
back over separate REST requests.

| Frame | Meaning | Worker action |
| --- | --- | --- |
| `session {sessionId, ownerEpoch}` | New ephemeral owner-bound generation | Register stream with coordinator |
| `task.leased {creditId, task}` | At most one task for this offer | Validate reservation, then execute |
| `credit.unused {creditId}` | No task delivered for this offer | Release reservation and consider another shard |
| `: keepalive` comment | Stream is alive; no task assignment | Continue reading |

Source: [stream writer](../src/WorkflowCore.Hub.Gateway/HubSseTaskDistributor.cs),
[relay flushing](../src/WorkflowCore.Hub.Gateway/HubMatchingOwnership.cs),
[SSE reader and execution](../src/WorkflowCore.RemoteExecution/HubRuntimeWorkers.cs).

## 12. Phase 8 — execute workflow decisions, then activities, then resume

A workflow task and an activity task use the same delivery machinery but have
different execution and completion contracts.

```mermaid
sequenceDiagram
    autonumber
    participant WL as Remote workflow lane
    participant Hub as Hub REST / transactional stores
    participant PG as PostgreSQL
    participant AL as Remote activity lane
    Hub-->>WL: SSE leased __native_workflow__ task
    WL->>Hub: GET workflow native-runtime
    Hub-->>WL: Snapshot, revision, unread inbox, definition identity
    WL->>WL: Execute native workflow turn and derive activity dispatch
    WL->>Hub: POST native-commits with task epoch and expected revision
    Hub->>PG: Atomic snapshot + effects + history + workflow-task ACK
    Note over Hub,PG: Effect inserts activity task, constraints and pointer metadata
    Hub-->>WL: Commit accepted, workflow lane slot can be released
    Note over Hub,AL: Match activity to compatible credited activity session
    Hub-->>AL: SSE leased provision-tenant task
    AL->>AL: Execute registered handler
    AL->>Hub: REST task heartbeat while running
    AL->>Hub: POST task complete with worker ID, epoch and result
    Hub->>PG: Atomic activity completion + attempt/history + inbox + workflow wakeup
    Hub-->>AL: Completion accepted, activity lane slot can be released
    Note over Hub,WL: Match new workflow task to credited workflow session
    Hub-->>WL: SSE leased __native_workflow__ task
    WL->>Hub: Read native runtime including activity result
    WL->>WL: Apply result mapping and decide next action
    WL->>Hub: Commit next effects or Complete status
```

### Workflow execution turn

`HubNativeWorkflowWorker` fetches the durable runtime and invokes
`HubNativeExecutor` using the locally registered definition. The resulting
native commit includes a snapshot, consumed inbox messages, activity/timer
effects and history. It is fenced by the workflow task's owner/epoch and the
expected workflow revision.

The Hub validates registrations and dispatch keys, derives constraints, inserts
activity tasks in the workflow's partition, persists pointer/dispatch identity,
and acknowledges the workflow task in the same transaction as its snapshot.
It can schedule multiple effects for supported native workflow constructs;
the one-activity diagram is an illustrative simple turn.

The sequential compatibility path instead reads `/runtime` and posts a
`ScheduleActivity`, `ScheduleTimer`, or `CompleteWorkflow` transition. Its
Activity/Delay limitations should not be confused with native execution support.

### Activity execution and result

`HubNativeActivityWorker` invokes the registered local activity handler and
posts the result to `/api/hub/tasks/{id}/complete`. During execution, the worker
heartbeats approximately every ten seconds. A rejected renewal cancels local
execution; cooperative cancellation cannot undo an external side effect.

For a native activity, the completion transaction verifies the execution lease,
marks the task completed, closes its attempt, inserts a deduplicated Activity
inbox message, records history and wakes the workflow. The workflow worker
later consumes the result and advances the workflow snapshot.

If a completion response is lost, the worker retries its already computed
result rather than rerunning the handler in that same execution. The stores
recognize compatible replays. A subsequent lease retry after failure or expiry
can still repeat external effects, so handlers need idempotency or reconciliation.

### Durable waits

For a delay, the workflow turn commits a durable timer and releases its lane
slot. The embedded scheduler scans PostgreSQL due timers, records the outcome
and enqueues a workflow wakeup. The resumed task follows the same matching/SSE
path. No execution credit or worker thread is held for the entire business
delay. Native event outcomes similarly reach the durable inbox and wake the
workflow through Hub APIs. These are workflow wakeups, distinct from matching
readiness hints.

Source: [worker execution/result retry/heartbeat](../src/WorkflowCore.RemoteExecution/HubRuntimeWorkers.cs),
[native executor](../src/WorkflowCore.RemoteExecution/HubNativeExecutor.cs),
[native commit and activity completion](../src/WorkflowCore.Hub/HubNativeWorkflowStore.cs),
[sequential transitions](../src/WorkflowCore.Hub/HubRemoteWorkflowStore.cs),
[timer store](../src/WorkflowCore.Hub/HubTimerStore.cs).

## 13. Phase 9 — reconnect, fail over and recover uncertain delivery

Matching ownership and execution ownership are independent:

| Fence | Protects | Verified by |
| --- | --- | --- |
| Matching owner epoch | Which Hub generation may keep a session and distribute from it | Stream/credit routing, owner store and distributor checks |
| Task execution epoch plus worker identity/live lease | Which execution may heartbeat or complete one task | Task/workflow transactional stores |
| Workflow revision | Which workflow turn may advance a snapshot | Native commit or sequential transition transaction |

```mermaid
sequenceDiagram
    autonumber
    participant W as Worker with running task T and undelivered offer C
    participant A as Former owner Hub A
    participant PG as PostgreSQL
    participant B as New owner Hub B
    PG->>PG: A's shard ownership expires or is released
    B->>PG: Acquire shard with newer matching owner epoch
    A->>PG: Check captured epoch even with zero available credits
    PG-->>A: Old matching generation no longer owns shard
    A--xW: Abort stale SSE stream
    W->>W: Drop old session's undelivered offers and keep T reserved
    W->>B: Reconnect through public Gateway routing
    B-->>W: New session ID and matching owner epoch
    W->>B: REST heartbeat/complete T with original task epoch
    B->>PG: Validate T's execution lease, independent of matching owner
    W->>B: Offer new credit only for truly free capacity
```

An idle distributor checks its captured owner epoch approximately every two
seconds while waiting for credits. Therefore an old stream can be revoked even
when every local slot is occupied by running tasks. These intervals and the
eight-second ownership lease are implementation values, not failover latency
guarantees under load or outage.

| Failure window | Durable state | Recovery / implication |
| --- | --- | --- |
| No compatible worker or no offered credit | Task remains ready in PostgreSQL | Future compatible credited session can claim it |
| Lost readiness notification | Task remains ready or lease becomes reclaimable | Startup/probe/reconciliation scans rediscover it |
| Credit accepted, stream lost before task received | Task may still be ready or already leased | Worker discards old undelivered offer; any committed task lease waits for expiry/recovery |
| Owner changes after claim but before SSE write | Task lease may already be committed | Old distributor refuses delivery after its epoch check; normal task lease recovery applies |
| Late frame from revoked session | Task may be leased | Worker rejects it; it must not execute without a current reservation |
| Stream disconnects while task runs | Existing execution lease remains authoritative | Worker keeps running reservation and continues REST execution protocol |
| Worker dies during external activity | Side effect may have occurred; result may be absent | Lease retry can rerun activity; downstream idempotency/reconciliation required |
| Completion commits but response is lost | Completed task and workflow wakeup are durable | Retry frozen result; accepted replay does not create another logical outcome |
| Matching credit rejected after owner/session change | No valid credit registration for that request | Worker invalidates stream and reconnects instead of carrying credit to another epoch |

There is no durable delivery acknowledgement for an SSE frame and no exactly-once
external execution guarantee. A disconnected stream is not sufficient evidence
that its leased task can safely be immediately reassigned.

Source: [zero-credit epoch validation](../src/WorkflowCore.Hub.Gateway/HubSseTaskDistributor.cs),
[reconnect accounting](../src/WorkflowCore.RemoteExecution/HubSseWorkerCreditCoordinator.cs),
[SSE reconnect loop](../src/WorkflowCore.RemoteExecution/HubRuntimeWorkers.cs),
[owner leases](../src/WorkflowCore.Hub/HubMatchingPartitionLeaseStore.cs).

## 14. Worked trace: which Hub and which worker receive an activity?

These are hypothetical values to illustrate the implementation, not measured
deployment results. Assume namespace `example`, 32 persisted partitions, four
matching shards, Hub A owning shard 1 at epoch 12, and activity lane A1 with
capacity two.

| Step | Workflow/task action | Where the state lives |
| --- | --- | --- |
| 1 | Application starts Workflow W using idempotency key K | REST request to any Gateway |
| 2 | Start transaction stores W in partition 13 and creates workflow task F1 | PostgreSQL; F1 belongs to matching shard 1 |
| 3 | A compatible workflow lane has offered credit to its shard 1 session | Worker reservation and Hub A's ephemeral session queue |
| 4 | Matcher leases F1 to that lane; Hub A pushes it | PostgreSQL execution lease, then SSE response |
| 5 | Workflow worker commits an effect for `provision-tenant:3` | PostgreSQL snapshot/ACK plus activity task T1 in partition 13 |
| 6 | Matching hint targets namespace `example`, shard 1, activity version 3 | Advisory notification to local matchers |
| 7 | Lane A1 has session S1 on shard 1 and offered credit C1 | A1 reserves one of its two local slots |
| 8 | SQL checks T1's policies and leases it to A1, task epoch 7 | `hub_task.owner=A1`, `epoch=7`, live lease |
| 9 | Hub A sends `task.leased {creditId:C1, task:T1}` on S1 | Possibly relayed by Hub B and the public LB |
| 10 | A1 validates S1/C1, changes offer to running, invokes handler | A1 still consumes exactly one slot |
| 11 | A1 completes with worker ID A1 and task epoch 7 | PostgreSQL T1 completion, Activity inbox result and workflow wakeup |
| 12 | A1 frees its local slot; a credited workflow lane receives the wakeup | New execution turn; it need not run on the earlier remote replica |

The selection chain is therefore:

```text
workflow partition 13
  -> matching shard 1
  -> current PostgreSQL-recorded owner Hub A
  -> compatible waiting claim backed by session S1 / credit C1
  -> SQL admission and lease owner A1
  -> S1's response writer
  -> A1's SSE reader
  -> reserved local execution slot
```

No step requires a stable LB affinity to Hub A, a worker listening on a public
port, or storing workflow state in Hub A's process memory.

## 15. Enabling this path and distinguishing the fallback transports

The following conditions select SSE task push in the remote runtime:

| Setting / condition | Required behavior |
| --- | --- |
| Hub matching enabled | `WFC_HUB_MATCHING_ENABLED=true` on Hub replicas, with valid node IDs, advertise URLs and trusted peers |
| Matching shards | `WFC_HUB_MATCHING_PARTITIONS > 1`, agreeing across workers/Hub replicas and with persisted configuration |
| Worker matching enabled | `WFC_HUB_LONG_POLL_ENABLED=true`; the runtime's matching gate is reused for SSE push |
| Worker task-push flag | `WFC_HUB_TASK_SSE_PUSH=true` in the remote worker process |
| Namespace scope | Exactly one distinct business Hub namespace in that worker lane's capability set |
| Capacity | Positive effective lane concurrency; SSE caps it at 64 |
| Matching schema and routing | Required ordered migrations applied; trusted internal forwarding and unbuffered SSE route available |

`WFC_HUB_MATCHING_EVENT_GATED=true` selects the event-gated dispatcher described
above. It is enabled by the Make SSE experiment targets, but it is independent
of the worker transport choice. The server stream routes validate sharded
matching; the task-push flag is read by the worker to choose its transport.

The combined onboarding sample advertises multiple namespaces in its lanes,
so do not assume its default registration set exercises SSE task push. The
[offboarding processor](../sample/offboarding/WorkflowCore.Offboarding.Processor/Program.cs)
and the existing Make targets provide the dedicated experiment path:

```powershell
# After observability configuration; these commands start local services.
make obs-offboarding-sse-up OFFBOARD_PROCESSORS=8
make obs-offboarding-sse-test K6_OFFBOARD_COUNT=1000 K6_OFFBOARD_VUS=200
make obs-offboarding-sse-down
```

See the [original distributor guide](sse-task-distributor.md#6-run-locally-gnu-make-with-pwsh)
for setup. These commands are documentation examples, not a verification run
performed while writing this guide.

| Transport | SSE contains | Who requests durable task acquisition? |
| --- | --- | --- |
| Adaptive claims + `/workers/events` | `tasks.available` hints | Worker later calls `tasks:claim` |
| Matching `tasks:poll` | Legacy hint stream is a separate facility | Worker submits a bounded HTTP long poll; owner returns leases in response |
| SSE task push `tasks:stream` | `session`, `task.leased`, `credit.unused` | Owner consumes a worker credit and invokes the in-process matcher |

All three retain PostgreSQL task leases and fenced results. Only the last row
is the leased-task SSE flow explained here. Earlier documents describing SSE
as hints-only apply to that fallback, not this optional transport.

## 16. Source reading map and existing validation

| Read next | What it answers |
| --- | --- |
| [HubWorkflowClient](../src/WorkflowCore.RemoteExecution/HubWorkflowClient.cs) and [HubRestClient](../src/WorkflowCore.Hub.Client/HubRestClient.cs) | How does application input become an HTTP workflow start? |
| [HubGatewayEndpoints](../src/WorkflowCore.Hub.Gateway/HubGatewayEndpoints.cs) | Which REST APIs start, commit, heartbeat and complete? |
| [HubRemoteWorkflowStore](../src/WorkflowCore.Hub/HubRemoteWorkflowStore.cs) | Where are start/initial task and sequential transitions committed? |
| [HubNativeWorkflowStore](../src/WorkflowCore.Hub/HubNativeWorkflowStore.cs) | How do native snapshots, activity effects, results and wakeups remain atomic? |
| [HubPolicies](../src/WorkflowCore.Hub/HubPolicies.cs) | How are partitions derived, and why is placement distinct from ordering? |
| [HubMatchingPartitionLeaseStore](../src/WorkflowCore.Hub/HubMatchingPartitionLeaseStore.cs) and [HubMatchingOwnership](../src/WorkflowCore.Hub.Gateway/HubMatchingOwnership.cs) | Who owns each shard, and how are peer streams routed? |
| [HubSseTaskStreamingEndpoints](../src/WorkflowCore.Hub.Gateway/HubSseTaskStreamingEndpoints.cs) | How are subscriptions/credits validated and forwarded? |
| [HubSseTaskDistributor](../src/WorkflowCore.Hub.Gateway/HubSseTaskDistributor.cs) | How does one credit produce one delivery or unused response? |
| [HubTaskMatcher](../src/WorkflowCore.Hub.Gateway/HubTaskMatcher.cs) and [HubEventGatedClaimDispatcher](../src/WorkflowCore.Hub.Gateway/HubEventGatedClaimDispatcher.cs) | How does readiness select compatible waiting demand? |
| [HubTaskStore](../src/WorkflowCore.Hub/HubTaskStore.cs) | Which SQL checks enforce eligibility, permits, FIFO and execution fencing? |
| [HubSseWorkerCreditCoordinator](../src/WorkflowCore.RemoteExecution/HubSseWorkerCreditCoordinator.cs) | How can credits move between shards without losing running reservations? |
| [HubRuntimeWorkers](../src/WorkflowCore.RemoteExecution/HubRuntimeWorkers.cs) | How do registration, transport selection, SSE parsing, execution and result retry fit together? |
| [PostgresHubNotificationListener](../src/WorkflowCore.Hub.Gateway/PostgresHubNotificationListener.cs), [HubReadinessBroadcaster](../src/WorkflowCore.Hub.Gateway/HubReadinessBroadcaster.cs), [migration 019](../sql/019_hub_matching_partition_hints.sql) | Where do hints originate, and how is missed work rediscovered? |

Existing tests provide executable examples of the invariants:

- [HubSseTaskDistributorTests](../tests/WorkflowCore.Scaling.PostgreSQL.Tests/HubSseTaskDistributorTests.cs):
  one-shot delivery, unused grants, zero-credit owner loss, session replacement
  and invalid initial credits/epochs; uses injected matching without PostgreSQL.
- [HubSseWorkerCreditCoordinatorTests](../tests/WorkflowCore.Scaling.PostgreSQL.Tests/HubSseWorkerCreditCoordinatorTests.cs):
  global per-lane capacity, moving idle grants, stale-frame rejection,
  reconnect retaining running tasks, and more shards than available slots.
- [HubMatchingPartitionTests](../tests/WorkflowCore.Scaling.PostgreSQL.Tests/HubMatchingPartitionTests.cs):
  independent owners, expired takeover, graceful release, count mismatch and
  concurrent election; requires the configured PostgreSQL test environment.
- [Dedicated SSE E2E workflow](../../.github/workflows/workflow-hub-sse-push-e2e.yml):
  local Compose/CI recipe exercising policy workloads and Hub failover.

These references identify coverage and runnable checks. They do not claim the
tests or E2E environment were executed as part of this documentation change.
